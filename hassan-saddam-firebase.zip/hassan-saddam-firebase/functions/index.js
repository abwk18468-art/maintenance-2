const { onSchedule } = require('firebase-functions/v2/scheduler');
const { onRequest, onCall, HttpsError } = require('firebase-functions/v2/https');
const { onDocumentCreated } = require('firebase-functions/v2/firestore');
const { defineSecret } = require('firebase-functions/params');
const admin = require('firebase-admin');
admin.initializeApp();
const fs = admin.firestore();
const TG = defineSecret('TELEGRAM_BOT_TOKEN');
const WA = defineSecret('WHATSAPP_TOKEN');
const DAY = 864e5;

/* ---------- قراءة بيانات المحل (نفس تخطيط التطبيق) ---------- */
async function load(shopId) {
  const snap = await fs.collection(`shops/${shopId}/docs`).get();
  const D = {};
  snap.forEach(d => (D[d.id] = d.data()));
  const ids = Object.keys(D);
  const L = k => ids.filter(i => new RegExp(`^c-${k}(-\\d+)?$`).test(i)).sort().flatMap(i => D[i].list || []);
  return {
    set: (D.main || {}).set || {},
    cust: L('cust'), ins: L('ins'), rep: L('rep'),
    tx: ids.filter(i => i.startsWith('tx-')).flatMap(i => D[i].list || []),
    tg: (D.links || {}).tg || {},
    log: D.notifylog || {},
  };
}

/* ---------- منطق الديون (مطابق للتطبيق) ---------- */
const rate = s => s.rate || 1500;
const iq = (t, s) => t.amt * (t.cur === 'USD' ? rate(s) : 1);
const fm = (n, c, s) => (c === 'USD' ? '$' + n.toLocaleString('en-US') : n.toLocaleString('en-US') + ' ' + (s.cur || 'د.ع'));
function overdue(cid, tx, s) {
  const T = tx.filter(t => t.cid === cid).sort((a, b) => a.d - b.d);
  let p = 0, o = 0;
  T.forEach(t => { if (t.type === 'pay') p += iq(t, s); });
  T.forEach(t => {
    if (t.type !== 'debt') return;
    const r = Math.max(0, iq(t, s) - p);
    p = Math.max(0, p - iq(t, s));
    if (r > 0 && t.due && t.due < Date.now()) o += r;
  });
  return o;
}
function balStr(cid, tx, s) {
  const b = { IQD: 0, USD: 0 };
  tx.forEach(t => { if (t.cid === cid) b[t.cur || 'IQD'] += t.type === 'debt' ? t.amt : -t.amt; });
  return [b.IQD && fm(b.IQD, 'IQD', s), b.USD && fm(b.USD, 'USD', s)].filter(Boolean).join(' + ') || fm(0, 'IQD', s);
}
function lateInst(cid, d) {
  return d.ins.filter(p => p.cid === cid).map(p => {
    const paid = d.tx.filter(t => t.cid === cid && t.type === 'pay' && !t.ret && (t.cur || 'IQD') === p.cur && t.d > p.start + 1).reduce((a, t) => a + t.amt, 0);
    const rem = p.total - p.dp;
    let due = 0;
    for (let i = 1; i <= p.n; i++) { const x = new Date(p.start); x.setMonth(x.getMonth() + i); if (x <= Date.now()) due = Math.min(rem, i * p.mo); }
    return { cur: p.cur, late: Math.max(0, due - paid) };
  }).filter(x => x.late > 0);
}
const intl = (p, cc) => { p = String(p || '').replace(/\D/g, ''); if (p.startsWith('00')) p = p.slice(2); else if (p.startsWith('0')) p = (cc || '964') + p.slice(1); return p; };

/* ---------- الإرسال ---------- */
const tgSend = (token, chat, text) => fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
  method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ chat_id: chat, text }),
}).then(r => r.json());
const waSend = (token, pid, to, tpl, params) => fetch(`https://graph.facebook.com/v20.0/${pid}/messages`, {
  method: 'POST', headers: { Authorization: 'Bearer ' + token, 'content-type': 'application/json' },
  body: JSON.stringify({ messaging_product: 'whatsapp', to, type: 'template', template: { name: tpl, language: { code: 'ar' }, components: [{ type: 'body', parameters: params.map(t => ({ type: 'text', text: String(t) })) }] } }),
}).then(r => r.json());

async function run(shopId, tok, force) {
  const d = await load(shopId), s = d.set, now = Date.now();
  if (!s.notify) return { sent: 0, late: 0, note: 'الإرسال التلقائي غير مفعّل' };
  const every = (s.notifyEvery || 3) * DAY, log = { ...d.log }, late = [];
  let sent = 0;
  for (const c of d.cust) {
    const o = overdue(c.id, d.tx, s), li = lateInst(c.id, d);
    if (o <= 0 && !li.length) continue;
    late.push({ c, o, li });
    if (!force && now - (log[c.id] || 0) < every) continue;
    const bal = balStr(c.id, d.tx, s);
    const text = [`⏰ تذكير — ${s.shop || 'المحل'}`, `السيد/ة ${c.name}`, o > 0 ? `مبلغ متأخر: ${fm(o, 'IQD', s)}` : '', ...li.map(l => `قسط متأخر: ${fm(l.late, l.cur, s)}`), `إجمالي الرصيد: ${bal}`, s.ft || ''].filter(Boolean).join('\n');
    let ok = false;
    if (s.notifyTg && d.tg[c.id]) ok = !!(await tgSend(tok.tg, d.tg[c.id], text)).ok || ok;
    if (s.notifyWa && s.waPhoneId && c.phone) {
      const amt = [o > 0 && fm(o, 'IQD', s), ...li.map(l => fm(l.late, l.cur, s))].filter(Boolean).join(' + ');
      ok = !!(await waSend(tok.wa, s.waPhoneId, intl(c.phone, s.cc), s.waTemplate || 'debt_reminder', [c.name, amt, s.shop || 'المحل'])).messages || ok;
    }
    if (ok) { log[c.id] = now; sent++; }
  }
  if (s.notifyTg && d.tg.owner && late.length) {
    await tgSend(tok.tg, d.tg.owner, `📋 ملخص المتأخرات (${late.length} زبون)\n` + late.slice(0, 40).map(x => `• ${x.c.name}: ${x.o > 0 ? fm(x.o, 'IQD', s) : ''}${x.li.length ? ' + أقساط' : ''}`).join('\n') + `\nتم إرسال ${sent} تذكير للزبائن.`);
  }
  // تنبيهات للمالك: أجهزة تأخر تسليمها + أقساط قريبة
  const lateRep = d.rep.filter(r => r.eta && r.eta < now && (r.s || 0) < 2);
  const soon = d.ins.filter(p => { for (let i = 1; i <= p.n; i++) { const x = new Date(p.start); x.setMonth(x.getMonth() + i); const t = x.getTime(); if (t > now && t - now < (s.remD || 3) * DAY) return true; } return false; });
  if (s.notifyTg && d.tg.owner && (lateRep.length || soon.length)) {
    await tgSend(tok.tg, d.tg.owner, `⏰ تنبيهات ${s.shop || 'المحل'}\n` + (lateRep.length ? `🔧 أجهزة تأخر تسليمها (${lateRep.length}):\n` + lateRep.slice(0, 15).map(r => `• ${r.name} — ${r.dev}`).join('\n') + '\n' : '') + (soon.length ? `🗓 أقساط تستحق قريباً (${soon.length}):\n` + soon.slice(0, 15).map(p => `• ${(d.cust.find(c => c.id === p.cid) || {}).name || ''} — ${fm(p.mo, p.cur, s)}`).join('\n') : ''));
  }
  await fs.doc(`shops/${shopId}/docs/notifylog`).set(log);
  return { sent, late: late.length, lateRepairs: lateRep.length, soonInstallments: soon.length };
}

/* ---------- الدوال ---------- */
// كل يوم الساعة 10 صباحاً بتوقيت بغداد
exports.daily = onSchedule({ schedule: 'every day 10:00', timeZone: 'Asia/Baghdad', secrets: [TG, WA] }, async () => {
  const shops = await fs.collection('shops').listDocuments();
  for (const sh of shops) { try { await run(sh.id, { tg: TG.value(), wa: WA.value() }, false); } catch (e) { console.error(sh.id, e); } }
});
// زر "إرسال الآن" في التطبيق
exports.sendNow = onCall({ secrets: [TG, WA] }, async req => {
  if (!req.auth) throw new HttpsError('unauthenticated', 'سجّل الدخول أولاً');
  const shopId = (req.data || {}).shopId;
  if (!shopId) throw new HttpsError('invalid-argument', 'shopId مطلوب');
  const m = await fs.doc(`shops/${shopId}/members/${req.auth.uid}`).get();
  if (!m.exists || m.data().active === false || !['owner', 'accountant'].includes(m.data().role)) throw new HttpsError('permission-denied', 'غير مصرّح');
  return run(shopId, { tg: TG.value(), wa: WA.value() }, true);
});
// ويب هوك تيليكرام: يربط محادثة الزبون/المالك عند الضغط على Start
exports.tgwebhook = onRequest({ secrets: [TG] }, async (req, res) => {
  const m = (req.body || {}).message;
  const mt = m && m.text && m.text.match(/^\/start\s+(\S+)/);
  if (mt) {
    const [shopId, tail] = mt[1].split('__');
    if (shopId && tail) {
      await fs.doc(`shops/${shopId}/docs/links`).set({ tg: { [tail]: m.chat.id } }, { merge: true });
      await tgSend(TG.value(), m.chat.id, '✅ تم تفعيل إشعارات الحساب على تيليكرام.');
    }
  } else if (m) {
    await tgSend(TG.value(), m.chat.id, 'مرحباً! استخدم الرابط الذي أرسله لك المحل لتفعيل الإشعارات.');
  }
  res.send('ok');
});
// تنبيه المالك عند دخول من جهاز جديد
exports.newLogin = onDocumentCreated({ document: 'shops/{shopId}/logins/{id}', secrets: [TG] }, async event => {
  const l = event.data && event.data.data();
  if (!l || l.first) return;
  const links = await fs.doc(`shops/${event.params.shopId}/docs/links`).get();
  const owner = ((links.data() || {}).tg || {}).owner;
  if (!owner) return;
  await tgSend(TG.value(), owner, `⚠ تسجيل دخول من جهاز جديد\nالمستخدم: ${l.name} (${l.role})\nالجهاز: ${l.ua}\nإن لم يكن هذا مصرّحاً فأوقف الحساب من «الموظفون».`);
});
